﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RegisterApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace RegisterApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly OurExcelDataContext ourExcelDataContext;
        private readonly object Log;

        public UserController(OurExcelDataContext ourExcelData)
        {
            ourExcelDataContext = ourExcelData;
        }

        [HttpPost("authenticate")]
        public async Task<IActionResult> Authentication([FromBody] Usertable usertable)
        {
            if (usertable == null)
                return BadRequest();
            var user = await ourExcelDataContext.Usertables.FirstOrDefaultAsync(x => x.UserName == usertable.UserName && x.Password == usertable.Password);
            if (user == null)
                return NotFound(new { Message = "User Not Found" });
            return Ok(new
            {
                Message = "Login Success!"
            });

        }

        [HttpPost("Register")]
        public async Task<IActionResult> RegisterUser([FromBody] Usertable usertable)
        {
            if (usertable == null)
                return BadRequest();
            await ourExcelDataContext.Usertables.AddAsync(usertable);
            await ourExcelDataContext.SaveChangesAsync();
            return Ok(new
            {
                Message = "User Registered!"
            });
        }

        //[HttpPost]
        //public async Task<IHttpActionResult> Callbcknd([FromBody] string body)
        //{
        //    try
        //    {
        //        Log.Info(string.Format("called with data {0}", body));

        //        return Ok(new { Message = "It worked!" });
        //    }

        //    catch (Exception ex)
        //    {
        //        return base.Content(HttpStatusCode.InternalServerError, ex.ToString());
        //    }
        //}
    }
}

